<div>
    <p>This is footer of the page</p>
</div>