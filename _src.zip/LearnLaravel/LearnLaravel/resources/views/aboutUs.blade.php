@extends('master')

@section('title', 'About Us')

@section('sidebar')
@parent

<p>You are on About us Page</p>
@endsection

@section('content')
<p>Welcome to Beginning Laravel Course.</p>
@endsection
