@extends('master')

@section('title', 'Contact Us')


@section('content')
<p>To contact us please email on hiren@dave.com</p>
@endsection
